package in.example.pracseven;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    RadioButton btech, bms, bba;
    TextView tic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btech = (RadioButton) findViewById(R.id.btech);
        btech.setOnClickListener(MainActivity.this);
        bms = (RadioButton) findViewById(R.id.bms);
        bms.setOnClickListener(MainActivity.this);
        bba = (RadioButton) findViewById(R.id.bba);
        bba.setOnClickListener(MainActivity.this);
        tic = (TextView) findViewById(R.id.tic);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btech:
                tic.setText("Ajay Sir");
                break;

            case R.id.bms:
                tic.setText("Onkar Sir");
                break;

            case R.id.bba:
                tic.setText("NKS Sir");
                break;
        }
    }
}
