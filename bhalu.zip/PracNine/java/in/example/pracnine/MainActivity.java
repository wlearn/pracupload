package in.example.pracnine;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    RelativeLayout screen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        screen = (RelativeLayout) findViewById(R.id.screen);
    }

    public void red(View v) {
        screen.setBackgroundColor(Color.parseColor("#FF0000"));
    }

    public void green(View v) {
        screen.setBackgroundColor(Color.parseColor("#00FF00"));
    }

    public void blue(View v) {
        screen.setBackgroundColor(Color.parseColor("#0000FF"));
    }
}
