package in.example.practen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText un,pw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        un = (EditText) findViewById(R.id.user);
        pw = (EditText) findViewById(R.id.pass);
    }

    public void submit(View v) {
        String username = un.getText().toString();
        String password = pw.getText().toString();
        if (username.equals("admin") && password.equals("p123_q456"))
            Toast.makeText(MainActivity.this,"Login Successful",Toast.LENGTH_LONG).show();
        else
            Toast.makeText(MainActivity.this,"Login Failed",Toast.LENGTH_LONG).show();
    }
}
