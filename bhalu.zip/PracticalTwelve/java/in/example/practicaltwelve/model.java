package in.example.practicaltwelve;

public class model {
    int _id;
    String _name;
    String _marks;
    public model()
    {

    }

    public model(int id, String name , String marks)
    {
        this._id=id;
        this._name=name;
        this._marks=marks;

    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }

    public String get_marks() {
        return _marks;
    }

    public void set_marks(String _marks) {
        this._marks = _marks;
    }


}
