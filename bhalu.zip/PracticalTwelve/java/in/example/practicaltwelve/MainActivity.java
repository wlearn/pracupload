package in.example.practicaltwelve;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHandler db = new DatabaseHandler(this);

        /**
         * CRUD Operations
         * */
        // Inserting Contacts
        Log.d("Insert: ", "Inserting ..");
        db.addMarks(new model(1,"Ravi", "66"));
        db.addMarks(new model(2,"Srinivas", "75"));

        // Reading all contacts
        Log.d("Reading: ", "Reading all contacts..");
        List<model> models = db.getAllMarks();

        for (model cn : models) {
            String log = "Id: "+cn.get_id()+" ,Name: " + cn.get_name() + " ,Phone: " + cn.get_marks();
            // Writing Contacts to log
            Log.d("Name: ", log);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.insert:
                Intent intent = new Intent(this,Insert.class);
                startActivity(intent);
                break;
            case R.id.update:
                Intent intent1 = new Intent(this,Update.class);
                startActivity(intent1);
                break;
            case R.id.delete:
                Intent intent2 = new Intent(this,Delete.class);
                startActivity(intent2);
                break;


        }

    }
}
