package in.example.practicaltwelve;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class Delete extends AppCompatActivity implements View.OnClickListener{
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        editText = (EditText)findViewById(R.id.id);
    }

    @Override
    public void onClick(View view) {
        String name,marks,roll;
        int id;
        roll=editText.getText().toString();
        id=Integer.parseInt(roll);
        if(roll.matches(""))
        {
            Toast.makeText(this,"Incomplete or Mismatch data",Toast.LENGTH_SHORT).show();
        }
        else {
            DatabaseHandler db = new DatabaseHandler(this);
            db.deleteContact(id);
            Toast.makeText(this,"Item deleted",Toast.LENGTH_SHORT).show();
        }

    }
}
