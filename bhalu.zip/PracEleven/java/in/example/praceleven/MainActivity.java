package in.example.praceleven;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText user,pass;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = (EditText) findViewById(R.id.userid);
        pass = (EditText) findViewById(R.id.passwd);
        btn = (Button) findViewById(R.id.login);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usern = user.getText().toString(), passw = pass.getText().toString();
                if(usern.equals("admin")  && passw.equals("p123_q456")) {
                    Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_SHORT).show();
                    Intent in = new Intent(getApplicationContext(),AnotherActivity.class);
                    in.putExtra("username",usern);
                    startActivity(in);
                }
                else
                    Toast.makeText(getApplicationContext(),"Unable to Login",Toast.LENGTH_LONG).show();
            }
        });
    }
}
