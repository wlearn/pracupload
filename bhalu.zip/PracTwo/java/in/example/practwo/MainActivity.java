package in.example.practwo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toast("On Create Phase!");
    }

    @Override
    protected void onStart() {
        super.onStart();
        toast("On Start Phase!");
    }

    @Override
    protected void onResume() {
        super.onResume();
        toast("on Resume Phase!");
    }

    @Override
    protected void onPause() {
        super.onPause();
        toast("On Pause Phase!");
    }

    @Override
    protected void onStop() {
        super.onStop();
        toast("On Stop Phase!");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        toast("On Destroy Phase!");
    }

    public void toast(String str) {
        Toast.makeText(MainActivity.this,str,Toast.LENGTH_LONG).show();
    }
}
