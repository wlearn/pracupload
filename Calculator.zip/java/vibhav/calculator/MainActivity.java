package vibhav.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, be, bc, bb, bp, bplus, bminus, bmul, bdiv;
    TextView exp, ans;
    Float f1, f2, fr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // lines 21 to 57
        // assign variables to buttons
        // and set OnClickListener to buttons
        setContentView(R.layout.activity_main);
        b0 = (Button) findViewById(R.id.btn_0);
        b0.setOnClickListener(MainActivity.this);
        b1 = (Button) findViewById(R.id.btn_1);
        b1.setOnClickListener(MainActivity.this);
        b2 = (Button) findViewById(R.id.btn_2);
        b2.setOnClickListener(MainActivity.this);
        b3 = (Button) findViewById(R.id.btn_3);
        b3.setOnClickListener(MainActivity.this);
        b4 = (Button) findViewById(R.id.btn_4);
        b4.setOnClickListener(MainActivity.this);
        b5 = (Button) findViewById(R.id.btn_5);
        b5.setOnClickListener(MainActivity.this);
        b6 = (Button) findViewById(R.id.btn_6);
        b6.setOnClickListener(MainActivity.this);
        b7 = (Button) findViewById(R.id.btn_7);
        b7.setOnClickListener(MainActivity.this);
        b8 = (Button) findViewById(R.id.btn_8);
        b8.setOnClickListener(MainActivity.this);
        b9 = (Button) findViewById(R.id.btn_9);
        b9.setOnClickListener(MainActivity.this);
        be = (Button) findViewById(R.id.btn_equal);
        be.setOnClickListener(MainActivity.this);
        bc = (Button) findViewById(R.id.btn_clr);
        bc.setOnClickListener(MainActivity.this);
        bb = (Button) findViewById(R.id.btn_bksp);
        bb.setOnClickListener(MainActivity.this);
        bp = (Button) findViewById(R.id.btn_point);
        bp.setOnClickListener(MainActivity.this);
        bplus = (Button) findViewById(R.id.btn_plus);
        bplus.setOnClickListener(MainActivity.this);
        bminus = (Button) findViewById(R.id.btn_minus);
        bminus.setOnClickListener(MainActivity.this);
        bmul = (Button) findViewById(R.id.btn_mul);
        bmul.setOnClickListener(MainActivity.this);
        bdiv = (Button) findViewById(R.id.btn_div);
        bdiv.setOnClickListener(MainActivity.this);
        // assign variables to TextViews
        exp = (TextView) findViewById(R.id.expression);
        ans = (TextView) findViewById(R.id.answer);
    }

    @Override
    public void onClick(View v) {
        // get the current expression
        String str = exp.getText().toString();
        // get id of the button which was clicked
        int id = v.getId();
        switch (id) {
            case R.id.btn_0:
                str += 0;
                exp.setText(str);
                break;

            case R.id.btn_1:
                str += 1;
                exp.setText(str);
                break;

            case R.id.btn_2:
                str += 2;
                exp.setText(str);
                break;

            case R.id.btn_3:
                str += 3;
                exp.setText(str);
                break;

            case R.id.btn_4:
                str += 4;
                exp.setText(str);
                break;

            case R.id.btn_5:
                str += 5;
                exp.setText(str);
                break;

            case R.id.btn_6:
                str += 6;
                exp.setText(str);
                break;

            case R.id.btn_7:
                str += 7;
                exp.setText(str);
                break;

            case R.id.btn_8:
                str += 8;
                exp.setText(str);
                break;

            case R.id.btn_9:
                str += 9;
                exp.setText(str);
                break;

            case R.id.btn_plus:
                if ((str.charAt(str.length() - 1) != '+') &&
                        (str.charAt(str.length() - 1) != '-') &&
                        (str.charAt(str.length() - 1) != 'x') &&
                        (str.charAt(str.length() - 1) != '/')) {
                    f1 = Float.parseFloat(exp.getText() + "");
                    str += '+';
                }
                ans.setText(str);
                exp.setText("");
                break;

            case R.id.btn_minus:
                if ((str.charAt(str.length() - 1) != '+') &&
                        (str.charAt(str.length() - 1) != '-') &&
                        (str.charAt(str.length() - 1) != 'x') &&
                        (str.charAt(str.length() - 1) != '/')) {
                    f1 = Float.parseFloat(exp.getText() + "");
                    str += '-';
                    ans.setText(str);
                    exp.setText("");
                }
                break;

            case R.id.btn_mul:
                if ((str.charAt(str.length() - 1) != '+') &&
                        (str.charAt(str.length() - 1) != '-') &&
                        (str.charAt(str.length() - 1) != 'x') &&
                        (str.charAt(str.length() - 1) != '/')) {
                    f1 = Float.parseFloat(exp.getText() + "");
                    str += 'x';
                    ans.setText(str);
                    exp.setText("");
                }
                break;

            case R.id.btn_div:
                if ((str.charAt(str.length() - 1) != '+') &&
                        (str.charAt(str.length() - 1) != '-') &&
                        (str.charAt(str.length() - 1) != 'x') &&
                        (str.charAt(str.length() - 1) != '/')) {
                    f1 = Float.parseFloat(exp.getText() + "");
                    str += '/';
                    ans.setText(str);
                    exp.setText("");
                }
                break;

            case R.id.btn_point:
                if ((str.charAt(str.length() - 1) != '.'))
                    str += '.';
                exp.setText(str);
                break;

            case R.id.btn_clr:
                str = "";
                exp.setText(str);
                break;

            case R.id.btn_equal:
                String anst = ans.getText().toString();
                if (anst.contains("+")) {
                    f2 = Float.parseFloat(exp.getText() + "");
                    ans.setText(String.valueOf(f1 + f2));
                    exp.setText(String.valueOf(f1 + f2));
                } else if (anst.contains("x")) {
                    f2 = Float.parseFloat(exp.getText() + "");
                    ans.setText(String.valueOf(f1 * f2));
                    exp.setText(String.valueOf(f1 * f2));
                } else if (anst.contains("-")) {
                    f2 = Float.parseFloat(exp.getText() + "");
                    ans.setText(String.valueOf(f1 - f2));
                    exp.setText(String.valueOf(f1 - f2));
                } else if (anst.contains("/")) {
                    f2 = Float.parseFloat(exp.getText() + "");
                    // check divide by 0 error
                    if (f2 == 0.0) {
                        ans.setText("Error");
                        exp.setText("");
                    } else {
                        ans.setText(String.valueOf(f1 / f2));
                        exp.setText(String.valueOf(f1 / f2));
                    }
                }
                break;

            case R.id.btn_bksp:
                if (str.length() > 0)
                    str = str.substring(0, str.length() - 1);
                exp.setText(str);
                break;
        }
    }
}
