var n;
var arr;

function run() {
	n = prompt ("Enter the number of elements in the array");
	arr = new Array ();
	for (var i=0; i<n; i++) {
		arr[i] = prompt ("Enter the element " + (i+1));
	}
	display();
}

function display() {
	console.log("Number of elements: " + n);
	
	var disp = "Unsorted Array: ";
	for (var i=0; i<n; i++) {
		disp += arr[i] + " ";
	}
	document.getElementById("unsorted").innerHTML=disp;
	console.log(disp);
	
	bubblesort();
	disp = "Sorted Array: ";
	for (var i=0; i<n; i++) {
		disp += arr[i] + " ";
	}
	document.getElementById("sorted").innerHTML=disp;
	console.log(disp);
}

function bubblesort() {
	for (var i=0; i<n-1; i++) {
		for (var j=n-1; j>i; j--) {
			if (arr[j] < arr[j-1]) {
				var temp = arr [j]
				arr[j] = arr[j-1];
				arr[j-1] = temp;
			}
		}
	}
}
