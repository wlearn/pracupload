function formcheck() {
    var firstname = document.myform.firstname.value;
    var lastname = document.myform.lastname.value;
    var rollno = document.myform.rollno.value;
	var year =  document.myform.year.value;
	var return_text;
	  
    if(!firstname.match(/[a-z]+/gi)) {
		alert("First name should be an alphabet string");
        return_text = false;
    }
      
	if(!lastname.match(/[a-z]+/gi)) {
		alert("Last name should be an alphabet string");
        return_text = false;
    }
    
    if(!rollno.match(/[0-9]+/gi)) {
		alert("Enter 7 digits in roll no");
        return_text = false;
    }
	
	if (year == "i") {
		alert("Please select your year");
		return_text = false;
	} 
	
	if (return_text == false) {
		document.getElementById("check").innerHTML = "Please fill form carefully";
		return false;
	}
	else {
		document.getElementById("check").innerHTML = "Form Submitted Successfully!";
		return true;
	}
}
