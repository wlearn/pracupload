function run () {
	var menu = "1. Push \n";
	menu += "2. Pop \n";
	menu += "3. Display Top Element \n";
	menu += "Any other key to EXIT";
	
	var choice;
	var content;
	var top = -1;
	const MAX_SIZE = 10;
	var serial = 0;
	var temp;
	var a = new Array();
	do {
		serial++;
		choice = Number(prompt(menu));
		content = serial + ": "; 
		switch(choice) {
			case 1:		stack_push();
						break;
					
			case 2:		stack_pop();
						break;
					
			case 3:		dispTopEl();
						break;
					
			default:	byebye(); 
						break;
		}
	} while((choice >= 1) && (choice <= 3));
	
	function isEmpty() {
		if(top == -1)
			return true;
		return false;
	}
	
	function isFull() {
		if(top == MAX_SIZE - 1)
			return true;
		return false;
	}	
	
	function stack_push() {
		content += "Push operation: ";
		if(!isFull()) {
			temp = prompt ("Enter the element to push: ");
			top++;
			a[top] = temp;
			content += "Successful. Element pushed: " + temp;
		}
		else
			content += "Unsuccessful. Reason: Stack Overflow!";
		alert(content.slice((content.indexOf(":")+1)));
		write(content);
		return;
	}	

	function stack_pop() {
		content += "Pop operation: ";
		if(!isEmpty()) {
			temp = a[top--];
			content += "Successful. Element popped: " + temp;
		}
		else
			content += "Unsuccessful. Reason: Stack Underflow!";
		alert(content.slice((content.indexOf(":")+1)));
		write(content);
		return;
	}

	function dispTopEl() {
		content += "Display Top Element: ";
		if(!isEmpty()) 
			content += "Successful. Top Element: " + a[top];
		else
			content += "Unsuccessful. Reason: Stack is Empty!";
		alert(content.slice((content.indexOf(":")+1)));
		write(content);
		return;
	}

	function byebye() {
		content += "Exiting... Successful! ";
		content += "Stack Contents: ";
		for(var i=0; i<=top; i++) {
			content += a[i] + " ";
		}
		content += "| Thanks for using. Bye!";
		write(content);
		return;
	}	
	
	function write(x) {
		var para = document.createElement("p");
		var element = document.getElementById("updateops");
		var node = document.createTextNode(x);
		para.appendChild(node);
		element.appendChild(para);
		console.log(x);
		updateStack();
		return;
	}
	
	function updateStack() {
		var stackElements="";
		for(var i=top; i>=0; i--) {
			stackElements += "<p>" + a[i] + "</p> <hr>";
		}
		document.getElementById("stack").innerHTML=stackElements;
	}	
}
