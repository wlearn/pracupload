var pass="p123_q456";
function pass_check() {
	var enter_pass = document.login.pass.value;
	var name = document.login.name.value;
	if(enter_pass==pass) {
		alert("Welcome: " + name);
		return true;
	}
			
	else {
		alert("Wrong password");
		return false;
	}
}