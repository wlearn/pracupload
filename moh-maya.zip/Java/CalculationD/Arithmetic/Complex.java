package Arithmetic;

public class Complex {
	private double real;
	private double imaginary;
	
	public Complex() {
		this.real = 0;
		this.imaginary = 0;
	}
	
	public Complex(double re, double im) {
		this.real = re;
		this.imaginary = im;
	}
	
	public void print() {
		System.out.println("(" + Double.toString(this.real) + ") + i (" + Double.toString(this.imaginary) + ")");
	}
	
	public Complex add(Complex c1, Complex c2) {
		this.real = c1.real + c2.real;
		this.imaginary = c1.imaginary + c2.imaginary;
		return this;
	}
	
	public Complex sub(Complex c1, Complex c2) {
		this.real = c1.real - c2.real;
		this.imaginary = c1.imaginary - c2.imaginary;
		return this;
	}
	
	public Complex mul(Complex c1, Complex c2) {
		this.real = c1.real * c2.real - c1.imaginary * c2.imaginary;
		this.imaginary = c1.real * c2.imaginary + c1.imaginary * c2.real;
		return this;
	}
	
	public Complex conjugate() {
		this.imaginary *= -1;
		return this;
	}
}
