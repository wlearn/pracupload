package Arithmetic;
import java.lang.Math;

public class Rational {
	private int numerator;
	private int denominator;
	
	public Rational() {
		this.numerator = 0;
		this.denominator = 1;
	}
	
	public Rational(int n,int d) {
		if(d<0) {
			n *= -1;
			d *= -1;
		} 
		this.numerator = n;
		this.denominator = d;
	}
	
	private int gcd(int x, int y) {
		x = Math.abs(x);
		y = Math.abs(y);
		if (y == 0)
			return x;
		return gcd(y,x%y);	
	}
	
	private int lcm(int x, int y) {
		return Math.abs(x*y)/gcd(x,y);
	}
	
	public Rational stdForm() {
		if(this.denominator < 0) {
			this.numerator *= -1;
			this.denominator *= -1;
		}
		int div = gcd(Math.abs(this.numerator),this.denominator);
		this.numerator /= div;
		this.denominator /= div;
		return this;
	}
	
	public Rational reciprocal() {
		int temp = this.numerator;
		this.numerator = this.denominator;
		this.denominator = temp;
		return this;
	} 
		
	public void print() {
		System.out.println("(" + Integer.toString(this.numerator) + "/" + Integer.toString(this.denominator) + ")");
		return;
	}
	
	public Rational add(Rational r1, Rational r2) {
		int d = lcm(r1.denominator, r2.denominator);
		this.denominator = d;
		this.numerator = (r1.numerator * d / r1.denominator) + (r2.numerator * d / r2.denominator);
		return this.stdForm();
	}
	
	public Rational sub(Rational r1, Rational r2) {
		int d = lcm(r1.denominator, r2.denominator);
		this.denominator = d;
		this.numerator = (r1.numerator * d / r1.denominator) - (r2.numerator * d / r2.denominator);
		return this.stdForm();
	}
	
	public Rational mul(Rational r1, Rational r2) {
		this.numerator = r1.numerator * r2.numerator;
		this.denominator = r1.denominator * r2.denominator;
		return this.stdForm();
	}
	
	public Rational div(Rational r1, Rational r2) {
		return mul(r1, r2.reciprocal());
	}
}
