import java.util.Scanner;
import java.lang.Math;

class Shape {
	int x1,y1,x2,y2;
	void getcoord() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter cordinated for 1st point ");
		x1=sc.nextInt(); y1=sc.nextInt();
		System.out.println("Enter cordinated for 2nd point ");
		x2=sc.nextInt(); y2=sc.nextInt();
	}
	void showcorrd() {
		System.out.println("cordinates for 1st point are "+x1+" "+y1);
		System.out.println("cordinates for 2nd point are "+x2+" "+y2);
	}
}
class Rect extends Shape {
	int l, b, x3, y3, x4, y4;
	void showcorrd() {
		 x3=x1; y3=y2;
		 x4=x2; y4=y1;
		l=(int)Math.pow(Math.pow((x4-x2),2)+Math.pow((y4-y2),2),0.5);
		b=(int)Math.pow(Math.pow((x3-x2),2)+Math.pow((y3-y2),2),0.5);
		System.out.println("The length of rectangle is "+l);
		System.out.println("The breadth of rectangle is "+b);
	}
}
class Coordinates {
	public static void main(String[] args) {
		Rect r = new Rect();
		Shape d = r;
		d.getcoord();
		d.showcorrd();
	}
}