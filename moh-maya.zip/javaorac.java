import java.sql.*;  
class javaorac{  
public static void main(String args[]){  
try{  
//step1 load the driver class  
Class.forName("oracle.jdbc.driver.OracleDriver");  
  
//step2 create  the connection object  
Connection con=DriverManager.getConnection(  
"jdbc:oracle:thin:@127.0.0.1:8080:xe","system","1");  
  
//step3 create the statement object  
Statement stmt=con.createStatement();  
  
  
/* //Creation of table
 String query="create table student (sid number primary key, sname varchar(12),sage number)";
	int  rs=stmt.executeUpdate(query);
        System.out.println("table has been created"); 

//Insertion into table
String query="insert into student values(1102,'Priya',18)";
int  rs=stmt.executeUpdate(query);
 System.out.println("value inserted"+rs); 

//select query  
ResultSet rs=stmt.executeQuery("select * from student");  
while(rs.next())  
System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));

//update query
int r1=stmt.executeUpdate("update student set sage=sage+100 where sid=1101");
System.out.println("value updated"+r1); 
ResultSet rs=stmt.executeQuery("select * from student");  
while(rs.next())  
System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));

//delete 
int r1=stmt.executeUpdate("delete from student where sid=1101");
System.out.println("value updated"+r1); 
ResultSet rs=stmt.executeQuery("select * from student");  
while(rs.next())  
System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));
 */


//step5 close the connection object  
con.close();  
  
}catch(Exception e){ System.out.println(e);}  
  
}  
}  