//Playfair cipher

#include<iostream>
using namespace std;
#include<stdio.h>
#include<math.h>

#include<string.h>
char A[5][5];
char key[10],cipher[10],decode[10],text[10],kb[15];
int len,plen,klen;

void input();
void matrix();
void printmatrix();
void insert(int );
void bogus();
int findpos(char,int&,int&);
void encrypt();
void decrypt();

int main()
{ 
 
 input();
 matrix();
 printmatrix();
 bogus();
 encrypt();
 decrypt();

return 0;

}
void printmatrix()
{
int i,j;
for(i=0;i<5;i++)
{   cout<<"\n";
	 for(j=0;j<5;j++)
	  {  cout<<A[i][j];
	     cout<<" ";

	   }
}


}

void input()
{   int i;
cout<<" Enter length of key: ";
cin>>len;
int flag=1;

do{

cout<<" Enter key :";
    flag=0;
for(i=0;i<len;i++)
{
 cin>>key[i];
 if(key[i]=='i' || key[i]=='j')
 { cout<<"\nInvalid key\n";
   
   flag=1;
   break;
 }

}

}while(flag==1);

cout<<" Enter length of text: ";
cin>>plen;
cout<<"\n Enter plaintext ";
for(i=0;i<plen;i++)
cin>>text[i];


}


void matrix()
{
int i,j,m,n,start,end;
 end=ceil(len/5);
 start=5;
 int k;
k=0;
for(i=0;i<=end;i++)
{
      if(i<end)
	start=5;
      else
	start=len%5;
  for(j=0;j<start;j++)
	   A[i][j]=key[k++];

}

m=ceil(len/5);
 n=len%5;
 for(k='a';k<='z';k++)
{
    for(i=0;i<len;i++)
    {
	      if(k==key[i])
	       { cout<<k;
		 break;
	       }

	       if(i==(len-1))
	       {
		  if(k=='j')
		  break;

		 if(k=='i')
		 {
			  A[m][n++]='i';
			    if(n==5)
			   {   n=0;
				m++;

			    if(m==5)
			     break;
			    }
		 }
		else
	       {
			A[m][n++]=k;
			 if(n==5)
			   {   n=0;
				m++;

			    if(m==5)
			     break;
			    }
		  }
	       }

    }
   if(m==5)
   break;
}

}

void bogus()
{
     int k=0;
     char ch1,ch2;

     int i=0;
     klen=0;
 
   ch1=kb[k++]=text[0];
   klen++;
   for(i=1;i<plen;i++)
   {      ch2=text[i];
		if(ch1==ch2)
	      {	kb[k++]='x';
	       kb[k++]=text[i];
	       klen=klen+2;
	       }
	       else
	     {  kb[k++]=text[i];
	      klen++;
	      }
	     ch1=ch2;
    // cout<<" "<<klen;
    }

   cout<<klen;

    if(((klen)%2) != 0)
  {
   kb[k]='x';
    klen++;
   }

   cout<<"\n plain text : ";
    for(i=0;i<klen;i++)
   {
	      cout<<kb[i];
   }


}

int findpos(char ch,int &row,int &col)
{
	int i,j;
	for(i=0;i<5;i++)
	{	for(j=0;j<5;j++)
		  {      if(A[i][j]==ch)
			      {  row=i;
				 col=j;
				  break;
			       }

		  }
	 }
       return 0;
}

void encrypt()
{      int i,c,j,k=0,t=0,row1,col1,row2,col2;
	char ch1,ch2;
	c=0;

	for(i=0;i< (klen/2);i++)
	{      ch1=kb[k++];
	       ch2=kb[k++];

		findpos(ch1,row1,col1);
		findpos(ch2,row2,col2);

		if(row1==row2)
		{     cipher[c++]=A[row1][((col1+1)%5)];
			cipher[c++]=A[row1][((col2+1)%5)];
		     
		      t=t+2;
		}
		else if(col1==col2)
		{      cipher[c++]=A[(row1+1)%5][col1];
			cipher[c++]=A[(row2+1)%5][col1];
		       
			t=t+2;
		}
		else
		{
		       cipher[c++]=A[row1][col2];
		       cipher[c++]=A[row2][col1];
		       			t=t+2;
		}


	}

     cout<<"\n Cipher text : ";

   for(i=0;i<t;i++)
    cout<<cipher[i];



}

void decrypt()
{      int i,c,j,k=0,t=0,row1,col1,row2,col2;
	char ch1,ch2;
	c=0;

	for(i=0;i<(klen/2);i++)
	{      ch1=cipher[k++];
	       ch2=cipher[k++];

		findpos(ch1,row1,col1);
		findpos(ch2,row2,col2);
	    
		if(row1==row2)
		{     if(col1==0)
			 col1=5;

		       if(col2==0)
		       col2=5;

		      decode[c++]=A[row1][((col1-1)%5)];
		      decode[c++]=A[row1][((col2-1)%5)];
		      t=t+2;
		}
		else if(col1==col2)
		{     if(row1==0)
			row1=5;

			if(row2==0)
			row2=5;


		 decode[c++]=A[(row1-1)%5][col1];
		 decode[c++]=A[(row2-1)%5][col1];
		       //	cout<<cipher[0]<<" "<<cipher[1];
		       //	break;
			t=t+2;
		}
		else
		{
		       decode[c++]=A[row1][col2];
		       decode[c++]=A[row2][col1];
		       //cout<<cipher[0]<<" "<<cipher[1];
		       //	break;
			t=t+2;
		}


	}

     cout<<"\n decrypted text : ";

   for(i=0;i<t;i++)
    cout<<decode[i];

cout<<endl;

}
