#include<iostream>
#include<string.h>
using namespace std;
int mul_inverse(int x)
{
	int i;
	for(i=1;i<26;i++)
		if((x*i)%26==1)
			break;
	return i;	
}
int map_alpha_to_num(char a)
{	
	int i=(int)a;
	if(i>=97&&i<=122)
		i=i-96;
	return i;
}
void encrypt(int a,int b,char *text)
{
	int len=strlen(text),i=0,val;
	for(i=0;i<len;i++)
	{
		val=map_alpha_to_num(text[i]);			
		if(val<26)
			val=(val*a+b)%26;	
		val+=96;
		text[i]=(char)val;		
	}
}
void decrypt(int a,int b,char *text)
{
	int len=strlen(text),i=0,val;
	for(i=0;i<len;i++)
	{
		val=map_alpha_to_num(text[i]);
		if(val<26)	
			val=a*(val-b)%26;
		val+=96;
		text[i]=(char)val;
	}
}
int main()
{
	char text[100];
	int k1,k2,len;
	cout<<"\nEnter the 2 values for 2 keys\n";
	cin>>k1>>k2;
	cout<<"\nEnter the text\n";
	cin>>text;
	len=strlen(text);
	text[len]='\0';
	encrypt(k1,k2,text);
	cout<<"\nEncrypted text is:- "<<text<<"\n";
	k1=mul_inverse(k1);
	decrypt(k1,k2,text);
	cout<<"\nDecrypted text is:- "<<text<<"\n";
	return 0;
}
