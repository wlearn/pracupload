#include<iostream>
#include<string.h>
using namespace std;
int if_exists(char arr[5][5],char a,int row,int col)
{
	int i=0,j=0,flag=0;
	for(i=0;i<=row;i++)
	{
		for(j=0;j<=5;j++)
		{
			if(arr[i][j]==a)
			{
				flag=1;
				break;
			}
		}
		if(flag==1)
			break;
	}
	return flag;
}
void insert_key_in_array(char arr[5][5],char key[10],int &i,int &j)
{
	i=0;j=0;
	int len=strlen(key),flag=0,k=0;
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++,k++)
	        {
		        if(key[k]!='\0')
        		        arr[i][j]=key[k];
	                else
			{
        			flag=1;
	        	        break;
			}
	        }
	        if(flag==1)
	                break;
	}

}



void insert_remaining_array(char arr[5][5],char key[],int row,int col)
{
	int l=0,i=0,j=0,alpha=97,len=strlen(key),done;
	char a;
//first time completing incomplete row
	for(j=col;j<5;j++)
	{
		done=0;
		while(!done)
		{
			if((!if_exists(arr,(char)alpha,row,j))&&(alpha!=106))
			{
				arr[row][j]=(char)alpha;
				done=1;
			}
			alpha++;
		}
	}
	for(i=row+1;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			done=0;
			while(!done)
			{
				if((!if_exists(arr,(char)alpha,i,j))&&(alpha!=106))
				{
					arr[i][j]=(char)alpha;
					done=1;
				}
				alpha++;
			}
		}
	}
}
void remove_bogus(char text[],int len)
{
	text[len]='\0';
	int i=0,count=0,k=0;
	char text1[100];
	for(i=0;i<len;i++)
	{
		if(text[i]=='x'&&count==1)
		{
			text1[k]=text[i];
			k++;
			count=1;
		}
		else if(text[i]=='x'&&count==0)
		{
			count=1;
		}
		else if(text[i]!='x')
		{
			text1[k]=text[i];
			k++;
			count=0;
		}
	}
	cout<<"\nDecrpyted text is "<<text1<<"\n";
}
void decrypt(char ctext[],int len,char arr[5][5],int org_len)
{
	char decrypt_text[20],ch,ch1;
	int x1,y1,x2,y2,i,j,k;
	for(k=0;k<len;k+=2)
	{
		ch=ctext[k];
		ch1=ctext[k+1];
		for(i=0;i<5;i++)
		{
			for(j=0;j<5;j++)
			{
				if(ch==arr[i][j])
				{
					x1=i;
					y1=j;
				}
				if(ch1==arr[i][j])
				{
					x2=i;
					y2=j;
				}
			}
		}
		if(x1==x2)
		{
			decrypt_text[k]=arr[x1][(y1-1+5)%5];
			decrypt_text[k+1]=arr[x2][(y2-1+5)%5];
		}
		else if(y1==y2)
		{
			decrypt_text[k]=arr[(x1-1+5)%5][y1];
			decrypt_text[k+1]=arr[(x2-1+5)%5][y1];
		}
		else
		{
			decrypt_text[k]=arr[x1][y2];
			decrypt_text[k+1]=arr[x2][y1];
		}
	}
	decrypt_text[k]='\0';
	remove_bogus(decrypt_text,org_len);
}
void encrypt(char text[],int len,char arr[5][5],int org_len)
{
	char encrypt_text[20],ch,ch1;
	int x1,y1,x2,y2,i,j,k;
	for(k=0;k<len;k+=2)
	{
		ch=text[k];
		ch1=text[k+1];
		for(i=0;i<5;i++)
		{
			for(j=0;j<5;j++)
			{
				if(ch==arr[i][j])
				{
					x1=i;
					y1=j;
				}
				if(ch1==arr[i][j])
				{
					x2=i;
					y2=j;
				}
			}
		}
		if(x1==x2)
		{
			encrypt_text[k]=arr[x1][(y1+1)%5];
			encrypt_text[k+1]=arr[x2][(y2+1)%5];
		}
		else if(y1==y2)
		{
			encrypt_text[k]=arr[(x1+1)%5][y1];
			encrypt_text[k+1]=arr[(x2+1)%5][y1];
		}
		else
		{
			encrypt_text[k]=arr[x1][y2];
			encrypt_text[k+1]=arr[x2][y1];
		}
	}
	encrypt_text[k]='\0';
	cout<<"\nEncrpyted text is "<<encrypt_text<<"\n";
	cout<<"\nMatrix for checking\n";
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
			cout<<arr[i][j]<<"\t";
		cout<<"\n";
	}
	decrypt(encrypt_text,k,arr,len);
}
void addbogus(char text[],char arr[5][5],int len)
{
	char text1[20],a;
	int k=0,i;
	for(i=0;i<len;i++)
	{
		text1[k]=text[i];
		k++;
		if((text[i]=='x')&&(text[i-1]!='x'))
		{
			text1[k]=text[i];
			k++;
		}
		if((text[i]==text[i+1])&&(text[i]!='x'))
		{
			a='x';
			text1[k]=a;
			k++;
		}
	}
	if(k%2!=0)
	{
		a='y';
		text1[k]=a;//add bogus to make length even
		k++;
	}
	text1[k]='\0';
	text=text1;
	encrypt(text,k,arr,len);
}
char * remove_duplicate(char text[])
{
	char text1[100],*p;
	int i,k=0,flag,j;
	for(i=0;text[i]!='\0';i++)
	{
		flag=0;
		for(j=0;j<i;j++)
		{
			if(text[i]==text[j])
			{
				flag=1;
				break;
			}
		}
		if(!flag)
		{
			text1[k]=text[i];
			k++;
		}
	}
	text=text1;
	text[k]='\0';
	p=text;
	return p;
}
int main()
{
	char key[10],arr[5][5],a,text[20],*p;
	int i,j,flag,length,done,len;
	cout<<"\nEnter the key (of length atmost 9,not containing character 'J')\n";
	cin>>key;
	p=remove_duplicate(key);
	for(i=0;p[i]!='\0';i++)
		key[i]=p[i];
	key[i]='\0';
	insert_key_in_array(arr,key,i,j);
	insert_remaining_array(arr,key,i,j);
	cout<<"\nEnter the length of the text to be entered\n";
	cin>>len;
	cout<<"\nEnter the text\n";
	for(i=0;i<len;i++)
	{
		cin>>a;
		if(a=='j')
			a='i';
		text[i]=a;
	}
	cout<<"\nMatrix for checking\n";
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
			cout<<arr[i][j]<<"\t";
		cout<<"\n";
	}
	addbogus(text,arr,len);
	return 0;
}
