#include<iostream>
#include<string.h>
using namespace std;

void rotation(int pt[])
{
	int value=pt[0];
	int temp=pt[25];
	for(int i=0;i<26;i++)
	{
		int temp1=pt[i+1];
		pt[i+1]=value;
		value=temp1;	
	}
	pt[0]=temp;
}
int main()
{
	char plaintext[100];
	char enc[100];
	char dec[100];
	int pt[26]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25};
	int ct[26]={13,25,0,14,1,15,2,16,3,17,4,18,5,19,6,20,7,21,8,22,9,23,10,24,11,12};
	int pt1[26]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25};
	int ct1[26]={13,25,0,14,1,15,2,16,3,17,4,18,5,19,6,20,7,21,8,22,9,23,10,24,11,12};
	cout<<"Enter plaintext"<<endl;
	cin>>plaintext;
	int length=strlen(plaintext);
	int value,temp,index;
	for(int i=0;i<length;i++)
	{
		 index=(int)plaintext[i]-97;
		 value=pt[index];

		for(int j=0;j<26;j++)
		{
			if(ct[j]==value)
			{
				temp=j;	
				break;
			}
		}
		enc[i]=(char)temp+97;
		rotation(pt);
		rotation(ct);
		
	}
	cout<<"Encrypted text ";
	for(int z=0;z<length;z++)
		cout<<enc[z];
	cout<<endl;
	for(int k=0;k<length;k++)
	{
		 index=(int)enc[k]-97;
		 value=ct1[index];
		for(int l=0;l<26;l++)
		{
			if(pt1[l]==value)
			{
				temp=l;	
				break;
			}
		}
		dec[k]=(char)temp+97;
		rotation(pt1);
		rotation(ct1);
	}
	cout<<"Decrypted text "<<dec<<endl;
	return 0;

}
