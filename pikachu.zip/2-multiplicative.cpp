#include<iostream>
using namespace std;
int main()
{
	char text[100],ctext[100],dctext[100],ch,c,ch1;
	int key_inv,key,i,j=0;
	cout<<"\nEnter the plain text\n";
	cin>>text;
	cout<<"\nEnter the key\n";
	cin>>key;
	for(i=1;i<=26;i++)
	{
		if((key*i)%26==1)
			break;
	}		
	key_inv=i;
	while(1)
	{	
		ch=text[j];
		if(ch=='\0')
			break;
		else
		{
			c=((ch-96)*key)%26;
			if(c==0)
				c=c+64+26;
			else
				c+=64;	
			ctext[j]=c;
			ch1=((c-64)*key_inv)%26;
			if(ch1==0)
				ch1=ch1+96+26;
			else
				ch1+=96;
			dctext[j]=ch1;			
		}
		j++;
	}
	cout<<"\nEncrypted text is- "<<ctext;
	cout<<"\nDecrypted text is- "<<dctext<<"\n";
	return 0;
}	
