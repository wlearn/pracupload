#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<time.h>
using namespace std;
void rotate_int(int arr[])
{
	int i;
	char temp=arr[25];
	for(i=25;i>0;i--)
		arr[i]=arr[i-1];
	arr[i]=temp;
}
void rotate_char(char arr[])
{
	int i;
	char temp=arr[25];
	for(i=25;i>0;i--)
		arr[i]=arr[i-1];
	arr[i]=temp;
}
int map_int(int arr[],int a,int k)
{
	int i,flag=0,ret=27;
	for(i=0;i<k;i++)
		if(arr[i]==a)
		{
			flag=1;
			break;
		}
	if(flag=1)
		return i;	
	else
		return ret;	
}
int map(int arr[],int a,int k)
{
	int i,flag=0,ret=27;
	for(i=0;i<k;i++)
		if(arr[i]==a)
		{
			flag=1;
			break;
		}
	return flag;
}
int map_char(char arr[],char a)
{
	int i;
	for(i=0;i<26;i++)
		if(arr[i]==a)
			break;
	return i;	
}
void decrypt(char encrypt_text[],int len_encrypt_text,char key[])
{
	int pt,ky,ct,k;
	char decrypt_text[20];
	for(k=0;k<len_encrypt_text;k++)
	{
		ct=(int)(encrypt_text[k])-64;
		ky=(int)(key[k])-96;
		if(ct>=ky)
			pt=(ct-ky)+96;
		else
			pt=(ct-ky+26)+96;
		decrypt_text[k]=(char)pt;
	}
	decrypt_text[k]='\0';
	cout<<"\nDecrpyted text is "<<decrypt_text<<"\n";
}
void encrypt(char text[],int len,char text_arr[],int key_arr_index[])
{
	char encrypt_text[20];
	int pt,ky,ct,k;
	cout<<"\nPlain text array is\n";
	for(k=0;k<26;k++)
		cout<<text_arr[k]<<" ";
	cout<<"\n";
	cout<<"\nCipher text array is\n";
	for(k=0;k<26;k++)
		cout<<key_arr_index[k]<<" ";
	for(k=0;k<len;k++)
	{
		pt=map_char(text_arr,text[k]);
		ct=map_int(key_arr_index,pt,26);
		encrypt_text[k]=text_arr[ct];
		rotate_char(text_arr);
		rotate_int(key_arr_index);
	}
	encrypt_text[k]='\0';
	cout<<"\n\nEncrpyted text is "<<encrypt_text<<"\n";
	decrypt(encrypt_text,len,key_arr_index);
}
int main()
{
	srand (time(NULL));
	char text[20],text_arr[26];
	int key_arr_index[26],i,rand_val,len,val;
	cout<<"\nEnter the length of the text to be entered\n";
	cin>>len;
	cout<<"\nEnter the text(in lower case)\n";
	cin>>text;
	text[len]='\0';	
	for(i=0;i<26;i++)
	{
		val=i+97;
		text_arr[i]=(char)val;
		rand_val=rand()%26;
		if(i!=0)
		{
			while(map(key_arr_index,rand_val,i))
			{
				rand_val=rand()%26;
				cout<<rand_val<< " "<<i<<"i ";
			}			
		}
		key_arr_index[i]=rand_val;	
	}
	text_arr[i]='\0';
	encrypt(text,len,text_arr,key_arr_index);
	return 0;	
}
