package Arithmetic;

public class Complex {
	private Rational real;
	private Rational imaginary;
	
	public Complex() {
		this.real = new Rational(0,1);
		this.imaginary = new Rational (0,1);
	}
	
	public Complex(Rational re, Rational im) {
		this.real = re;
		this.imaginary = im;
	}
	
	public Complex(int n1, int n2, int n3, int n4) {
		Rational r1 = new Rational(n1, n2), r2 = new Rational(n3, n4);
		this.real = r1;
		this.imaginary = r2;
	}
	
	public void print() {
		this.real.print();
		System.out.print(" + i ");
		this.imaginary.print();
		System.out.println();
	}
	
	public Complex add(Complex c1, Complex c2) {
		this.real.add(c1.real, c2.real);
		this.imaginary.add(c1.imaginary, c2.imaginary);
		return this;
	}
	
	public Complex sub(Complex c1, Complex c2) {
		this.real.sub(c1.real, c2.real);
		this.imaginary.sub(c1.imaginary, c2.imaginary);
		return this;
	}
	
	public Complex mul(Complex c1, Complex c2) {
		Rational r1 = new Rational(), r2 = new Rational();
		r1.mul(c1.real, c2.real);
		r2.mul(c1.imaginary, c2.imaginary);
		this.real.sub(r1, r2) ;
		r1.mul(c1.real, c2.imaginary);
		r2.mul(c1.imaginary, c1.real);
		this.imaginary.add(r1, r2);
		return this;
	}
	
	public Complex conjugate() {
		Rational r = new Rational(-1,1);
		this.imaginary.mul(this.imaginary,r);
		return this;
	}
}

