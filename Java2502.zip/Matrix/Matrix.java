import java.util.Scanner;
import java.lang.*;

public class Matrix {
	private int rows,cols;
	private double m[][];
	
	public Matrix(int n1, int n2) { 
		this.rows = n1;
		this.cols = n2;
		this.m = new double[n1][n2];
		for(int i=0; i<n1; i++)
			for(int j=0; j<n2; j++)
				m[i][j] = 0;
	}
	
	public Matrix(double m2[][]) {
		this.m = m2;
		this.rows = m2.length;
		this.cols = m2[0].length;
	}
	
	public void display() {
		for(int i=0; i<this.rows; i++) {
			for(int j=0; j<this.cols; j++) 
				if (this.m[i][j] == Math.floor(this.m[i][j]))
					System.out.print("\t" + Integer.toString((int)(this.m[i][j])));
				else
					System.out.print("\t" + Double.toString(this.m[i][j]));
			System.out.println();
		}	
		System.out.println("*********************************************");
		return;	
	}
	
	public Matrix add(Matrix m1, Matrix m2) {
		for(int i=0; i<m1.rows; i++)
			for(int j=0; j<m1.cols; j++)
				this.m[i][j] = m1.m[i][j] + m2.m[i][j];
		return this;
	}
	
	public Matrix sub(Matrix m1, Matrix m2) {
		for(int i=0; i<m1.rows; i++)
			for(int j=0; j<m1.cols; j++)
				this.m[i][j] = m1.m[i][j] - m2.m[i][j];
		return this;
	}
	
	public Matrix mul(Matrix m1, Matrix m2) {
		for(int i=0; i<m1.rows; i++)
			for(int j=0; j<m2.cols; j++) {
				int sum = 0;
				for (int k=0; k<m1.cols; k++)
					sum += m1.m[i][k] * m2.m[k][j];
				this.m[i][j] = sum;
			}
		return this;
	}
	
	public Matrix tra(Matrix m1) {
		for(int j=0; j<m1.cols; j++)
			for(int i=0; i<m1.rows; i++)
				this.m[j][i] = m1.m[i][j];
		return this;
	}
	
	/************************************************************************/
	public static void main(String[] args) {
		int choice, n1, n2;
		double d1[][];
		Matrix one, two, three;
		Scanner in = new Scanner(System.in);
		String menu = "\t 1: Addition";
		menu += "\n\t 2: Subtraction";
		menu += "\n\t 3: Multiplication";
		menu += "\n\t 4: Transpose";
		menu += "\n\t Press ANY other key to Exit";
		
		do {
			System.out.println(menu);
			choice = in.nextInt();
			
			switch(choice) {
				case 1:		System.out.println("First Matrix: ");
							System.out.println("Enter the number of rows and columns: ");
							n1 = in.nextInt();
							n2 = in.nextInt();
							d1 = new double [n1][n2];
							input(d1,n1,n2);
							one = new Matrix(d1);
							System.out.println("Second Matrix: ");
							System.out.println("Enter the number of rows and columns: ");
							n1 = in.nextInt();
							n2 = in.nextInt();
							d1 = new double [n1][n2];
							input(d1,n1,n2);
							two = new Matrix(d1);
							if((one.rows == two.rows) && (one.cols == two.cols)) {
								three = new Matrix(one.rows,one.cols);
								three.add(one,two);
								System.out.println("Addition Operation Successful!");
								System.out.println("The Resultant matrix: ");
								three.display();
							}
							else
								System.out.println("Addition failed! Reason: Incompatible dimensions");
							break;
							
				case 2:		System.out.println("First Matrix: ");
							System.out.println("Enter the number of rows and columns: ");
							n1 = in.nextInt();
							n2 = in.nextInt();
							d1 = new double [n1][n2];
							input(d1,n1,n2);
							one = new Matrix(d1);
							System.out.println("Second Matrix: ");
							System.out.println("Enter the number of rows and columns: ");
							n1 = in.nextInt();
							n2 = in.nextInt();
							d1 = new double [n1][n2];
							input(d1,n1,n2);
							two = new Matrix(d1);
							if((one.rows == two.rows) && (one.cols == two.cols)) {
								three = new Matrix(one.rows,one.cols);
								three.sub(one,two);
								System.out.println("Subtraction Operation Successful!");
								System.out.println("The Resultant matrix: ");
								three.display();
							}
							else
								System.out.println("Subtraction failed! Reason: Incompatible dimensions");	
							break;
							
				case 3:		System.out.println("First Matrix: ");
							System.out.println("Enter the number of rows and columns: ");
							n1 = in.nextInt();
							n2 = in.nextInt();
							d1 = new double [n1][n2];
							input(d1,n1,n2);
							one = new Matrix(d1);
							System.out.println("Second Matrix: ");
							System.out.println("Enter the number of rows and columns: ");
							n1 = in.nextInt();
							n2 = in.nextInt();
							d1 = new double [n1][n2];
							input(d1,n1,n2);
							two = new Matrix(d1);
							if((one.cols == two.rows) && (one.rows == two.cols)) {
								three = new Matrix(one.rows,two.cols);
								three.mul(one,two);
								System.out.println("Multiplication Operation Successful!");
								System.out.println("The Resultant matrix: ");
								three.display();
							}
							else
								System.out.println("Multiplication failed! Reason: Incompatible dimensions");	
							break;
							
				case 4:		System.out.println("Enter the number of rows and columns: ");
							n1 = in.nextInt();
							n2 = in.nextInt();
							d1 = new double [n1][n2];
							input(d1,n1,n2);
							one = new Matrix(d1);
							three = new Matrix(one.cols,one.rows);
							three.tra(one);
							System.out.println("Transpose Operation Successful!");
							System.out.println("The Resultant matrix: ");
							three.display();	
							break;
					
				default:	System.out.println("Exiting Successful! Thanks for using.. Bye");
							break;
			}
		} while((choice >=1) && (choice <= 4));
		System.exit(0);
	}
	
	private static void input(double d[][], int n1, int n2) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the elements of the matrix: ");
		for(int i=0; i<n1; i++) 
			for(int j=0; j<n2; j++)
				d[i][j] = in.nextDouble();
	}
}
