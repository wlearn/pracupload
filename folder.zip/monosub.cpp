#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
using namespace std;

class MonoAlpha {
	private:
	char key[26];
	public:
	char str[30],estr[30],dstr[30];
	MonoAlpha(char k[]) {
		int i=0;
		for(i=0; i<26; i++)
			key[i]=k[i];
	}
	void encrypt(char s[]) {
		strcpy(estr," ");
		int i=0,len=strlen(s);
		for( i=0; i<len; i++)
			estr[i]=key[(s[i]-97)];
		estr[i]='\0';
		return;
	}
	void decrypt(char s[]) {
		strcpy(dstr," ");
		int i=0,len=strlen(s);
		for(i=0; i<len; i++) {
			for(int j=0; j<26; j++)
				if(s[i]==key[j])
					dstr[i]=toascii(j+97);
		}
		dstr[i]='\0';
		return;
	}
};


int main () {
    system("clear");
    char k[26];
	cout<<"Enter the keys [a-z]: ";
	cin>>k;
    MonoAlpha obj(k);
    cout<< "Enter the string: ";
    cin>>obj.str;
    obj.encrypt(obj.str);
    cout<<"Encrypted string: "<<obj.estr<<endl;
    obj.decrypt(obj.estr);
    cout<<"Decrypted string: "<<obj.dstr<<endl;
    return 0;
}
