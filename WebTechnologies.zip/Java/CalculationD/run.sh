#!/bin/bash
cd Arithmetic
javac Rational.java -d .
javac Complex.java -d .
cd ..
javac Calculation.java -d .
java Calculation
