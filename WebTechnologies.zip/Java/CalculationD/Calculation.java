import Arithmetic.*;
import java.util.Scanner;

public class Calculation {

	static void rMenu() {
		System.out.println("\t 1. Addition");
		System.out.println("\t 2. Subtraction");
		System.out.println("\t 3. Multiplication");
		System.out.println("\t 4. Division");
		System.out.println("\t 5. Reciprocal");
		System.out.println("\t ANY other key to EXIT");
	}
	
	static void cMenu() {
		System.out.println("\t 1. Addition");
		System.out.println("\t 2. Subtraction");
		System.out.println("\t 3. Multiplication");
		System.out.println("\t 4. Conjugate");
		System.out.println("\t ANY other key to EXIT");
	}
	
	static void mMenu() {
		System.out.println("\t 1. Rational");
		System.out.println("\t 2. Complex");
		System.out.println("\t ANY other key to EXIT");
	} 
	
	public static void main(String args[]) {
		String choice1, choice2;
		int n1, n2;
		Rational r1, r2, r3 = new Rational();
		Complex c1, c2, c3 = new Complex();
		double d1, d2;
		Scanner in = new Scanner(System.in);
		
		do {
			mMenu();
			choice1 = in.next();
			switch(choice1) {
				case "1":	rMenu();
							choice2 = in.next();
							switch(choice2) {
								case "1":	System.out.println("Enter the first number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r1 = new Rational(n1, n2);
											System.out.println("Enter the second number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r2 = new Rational(n1, n2);
											r3.add(r1, r2);
											System.out.print("ANSWER -->");
											r3.print();
											break;
								
								case "2":	System.out.println("Enter the first number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r1 = new Rational(n1, n2);
											System.out.println("Enter the second number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r2 = new Rational(n1, n2);
											r3.sub(r1, r2);
											System.out.print("ANSWER -->");
											r3.print();
											break;
								
								case "3":	System.out.println("Enter the first number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r1 = new Rational(n1, n2);
											System.out.println("Enter the second number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r2 = new Rational(n1, n2);
											r3.mul(r1, r2);
											System.out.print("ANSWER -->");
											r3.print();
											break;
								
								case "4":	System.out.println("Enter the first number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r1 = new Rational(n1, n2);
											System.out.println("Enter the second number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r2 = new Rational(n1, n2);
											r3.div(r1, r2);
											System.out.print("ANSWER -->");
											r3.print();
											break;
								
								case "5":	System.out.println("Enter the first number (n/d): ");
											n1 = in.nextInt();
											n2 = in.nextInt();
											r1 = new Rational(n1, n2);
											System.out.print("ANSWER -->");
											r3.print();
											break;
								
								default:	System.exit(0);
											break;
							}
							break;
							
				case "2":	cMenu();
							choice2 = in.next();
							switch(choice2) {
								case "1":	System.out.println("Enter the first number (re + i im): ");
											d1 = in.nextDouble();
											d2 = in.nextDouble();
											c1 = new Complex(d1, d2);
											System.out.println("Enter the second number (re + i im): ");
											d1 = in.nextDouble();
											d2 = in.nextDouble();
											c2 = new Complex(d1, d2);
											c3.add(c1, c2);
											System.out.print("ANSWER -->");
											c3.print();
											break;
								
								case "2":	System.out.println("Enter the first number (re + i im): ");
											d1 = in.nextDouble();
											d2 = in.nextDouble();
											c1 = new Complex(d1, d2);
											System.out.println("Enter the second number (re + i im): ");
											d1 = in.nextDouble();
											d2 = in.nextDouble();
											c2 = new Complex(d1, d2);
											c3.sub(c1, c2);
											System.out.print("ANSWER -->");
											c3.print();
											break;
								
								case "3":	System.out.println("Enter the first number (re + i im): ");
											d1 = in.nextDouble();
											d2 = in.nextDouble();
											c1 = new Complex(d1, d2);
											System.out.println("Enter the second number (re + i im): ");
											d1 = in.nextDouble();
											d2 = in.nextDouble();
											c2 = new Complex(d1, d2);
											c3.mul(c1, c2);
											System.out.print("ANSWER -->");
											c3.print();
											break;
								
								case "4":	System.out.println("Enter the number (re + i im): ");
											d1 = in.nextDouble();
											d2 = in.nextDouble();
											c1 = new Complex(d1, d2);
											c3 = c1.conjugate();
											System.out.print("ANSWER -->  ");
											c3.print();
											break;
								
								default:	System.exit(0);
											break;
							}
							break;
							
				default:	break;
			}
			System.out.println("**********************************************************");
		} while(choice1.compareTo("1") == 0 || choice1.compareTo("2") == 0);
		System.out.println("Exiting... Successful! Thanks for using.");
	}
}
