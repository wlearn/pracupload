#!/bin/bash
javac Matrix.java
java Matrix
