import java.util.Scanner;

class Point {
	public int X,Y;
	
	public Point() {
		X = 0;
		Y = 0;
	}
	
	public Point(int x, int y) {
		X = x;
		Y = y;
	}
}

class Shape {
	protected int numberOfEdges;
	private Point[] p;  
	
	public Shape() {
		numberOfEdges = 3;
		Point[] p= new Point [3];
	}
	
	public Shape(int n) {
		numberOfEdges = n;
	}
	
	public void getcoord() {
		System.out.println("Enter the Coordinates in order of joining: ");
		Scanner in = new Scanner(System.in);
		int x,y;
		for(int i=0; i<numberOfEdges; i++) {
			x = in.nextInt();
			y = in.nextInt();
			Point p[i] = new Point(x,y);
		}
		return;
	}
	
	public void showcoord() {
		System.out.println("The Coordinates are:");
		for(int i=0; i<numberOfEdges; i++) 
			System.out.println("(" + Integer.toString(p[i].X) + "," + Integer.toString(p[i].Y) + ")");
		return;
	}
}

class Rect extends Shape {
	public Rect() {
		numberOfEdges = 4;
	}
	
	@Override
	public void getcoord() {
		System.out.println("Enter the 2 opposite Coordinates: ");
		Scanner in = new Scanner(System.in);
		for(int i=0; i<4; i+=2) {
			x = in.nextInt();
			y = in.nextInt();
			Point p[i] = new Point(x,y);
		}
		if(p[0].Y < p[2].Y) {
			Point p[1] = new Point()
		}
			
		return;
	}
	
	@Override
	public void showcoord() {
		System.out.println("The Coordinates are:");
		for(int i=0; i<numberOfEdges; i++) 
			System.out.println("(" + Integer.toString(p[i].X) + "," + Integer.toString(p[i].Y) + ")");
		return;
	}
}

public class Coordinates {
	public static void main(String[] args) {
		System.exit(0);
	}
}
