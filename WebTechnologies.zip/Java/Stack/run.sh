#!/bin/bash
javac Stack.java
java Stack
