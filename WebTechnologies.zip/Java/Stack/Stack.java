import java.util.*;

abstract class AbstractStack {
	abstract void push(int e);
	abstract int pop();
	abstract void display();
	abstract boolean isEmpty();
	boolean isFull() {
		return false;
	}
}

class StaticStack extends AbstractStack {
	private int[] data;
	private int top;
	final int MAX_SIZE = 10;
	
	public StaticStack() {
		data = new int[MAX_SIZE];
		top = -1;
	}
	
	@Override
	public void push(int e) {
		data[++top] = e;
		return;
	}
	
	@Override
	public int pop() {
		return data[top--];
	}
	
	@Override
	public void display() {
		if(isEmpty()) {
			System.out.println("Stack is Empty!");
			return;
		}
		System.out.print("Stack Contents: ");
		for(int i=top; i>=0; i--)
			System.out.print(Integer.toString(data[i]) + " ");
		System.out.println("\t|");
		return;
	}
	
	@Override
	public boolean isEmpty() {
		return (top == -1);
	}
	
	public boolean isFull() {
		return (top == MAX_SIZE - 1);			
	}
}

class DynamicStack extends AbstractStack {
	ArrayList<Integer> data;
	
	public DynamicStack() {
		data = new ArrayList<Integer>();
	}
	@Override
	void push(int e) {
		data.add(e);
		return;
	}
	
	@Override
	int pop() {
		return data.remove(data.size()-1);
	}
	
	@Override
	void display() {
		if(isEmpty()) {
			System.out.println("Stack is Empty!");
			return;
		}
		System.out.print("Stack Contents: ");
		for(int i=data.size()-1; i>=0; i--) 
			System.out.print(Integer.toString(data.get(i)) + " ");
		System.out.println("\t|");
		return;
	}
	
	@Override
	public boolean isEmpty() {
		return data.isEmpty();
	}
}

public class Stack {
	static void mMenu() {
		System.out.println("\t 1. StaticStack");
		System.out.println("\t 2. DynamicStack");
		System.out.println("\t ANY other key to EXIT");	
	}
	
	static void sMenu() {
		System.out.println("\t 1. Push");
		System.out.println("\t 2. Pop");
		System.out.println("\t 3. Display");
		System.out.println("\t ANY other key to EXIT");
	}
	
	public static void main(String[] args) {
		String choice;
		AbstractStack s = new StaticStack();
		Scanner in = new Scanner(System.in);
		
		mMenu();
		choice = in.next();
		switch(choice) {
			case "1":	s = new StaticStack();
						break;
						
			case "2":	s = new DynamicStack();
						break;
						
			default:	System.exit(0);
		}
			
		do {
			sMenu();
			choice = in.next();
			switch(choice) {
				case "1":	if((s instanceof StaticStack)) {
								if(s.isFull())
									System.out.println("Stack Overflow! Unable to push.");
							}
							else {
								System.out.print("Enter the element to push: ");
								s.push(in.nextInt());
								System.out.println("Push operation Successful!");
							}
							break;
				
				case "2":	if(s.isEmpty())
								System.out.println("Stack Underflow! Unable to pop.");
							else {
								System.out.println("Pop operation Successful!");
								System.out.println("Element popped out: " + Integer.toString(s.pop()));			
							}
							break;
				
				case "3":	s.display();
							break;					
								
				default: 	;
			}
			System.out.println("******************************************************");			
		} while(choice.equals("1") || choice.equals("2") || choice.equals("3"));
		System.out.println("Exiting... Successful! Thanks for using.");
		System.exit(0);		
	}
}
