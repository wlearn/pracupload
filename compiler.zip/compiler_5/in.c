// This program adds two numbers
#include<stdio.h>

int main() {
	system("clear")
	int a,b,c=0;
	printf("Input 'a': ");
	scanf("%d",a);
	printf("Input 'b': ");
	scanf("%d",b);
	c=a+b;
	printf("\nThe sum is: %d",c);
	return 0;
}
