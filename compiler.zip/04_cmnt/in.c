// This program adds two numbers
#include<stdio.h>

int main() {
	system("clear");
	int a,b;
	printf("Input a: ");
	scanf("%d",&a);
	printf("Input b: ");
	scanf("%d",&b);
	printf("a + b = %d\n",a+b);
	return 0;
}
