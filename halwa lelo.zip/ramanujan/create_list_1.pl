list([],l1).
create_list([H|T],l1):-
	list(T,l1).
