sum_to(1,1):-!.
sum_to(N,X):-N>1,N1 is N-1,sum_to(N1,X1),X is N+X1.