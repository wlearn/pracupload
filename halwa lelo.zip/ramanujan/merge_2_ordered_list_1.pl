merge([],L,L).
merge([H1|T1],[H2|T2],[H3|T3]):-
	H1>H2,H3 is H2, merge([H1|T1],T2,T3).

merge([H1|T1],[H2|T2],[H3|T3]):-
	H2>H1,H3 is H1, merge(T1,[H2|T2],T3).

merge(L,[],L).
merge([H1|T1],[H2|T2],[H3,H4|T3]):-
	H1=:=H2, H3 is H1, H4 is H2, merge(T1,T2,T3).