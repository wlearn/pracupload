add(X,L):-member(X,L),!.
add(X,L,[X|L]).