max(X,X,X).
max(X,Y,X):-
X>Y.
max(X,Y,Y):-
Y>X.

maxlist([X],X).
maxlist([X,Y|Tail],N):-
maxlist([Y|Tail],N1),
max(X,N1,N).