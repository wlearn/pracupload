palin(List):-
	rev(List,List2),
	compare(List,List2).

conc([],L,L).
conc([X|L1],L2,[X|L3]):-conc(L1,L2,L3).
rev([Head],[Head]).
rev([Head|Tail],X):-
	rev(Tail,X1),
	conc(X1,[Head],X).

compare([],[]):-
	write("\nList is a pallindrome").
compare([X|Tail],[X|Tail1]):-
	compare(Tail,Tail1).
compare([Head|Tail],[Head1|Tail1]):-
	write("\nList is not pallindrome").
