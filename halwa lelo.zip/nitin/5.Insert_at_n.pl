insert(X,[],1,[X]).
insert(X,List,1,[X|List]).
insert(X,[Head|List],N,[Head|List1]):-
	N1 is N-1,N1>0,
	insert(X,List,N1,List1).
