max(X,Y,Y):- Y>X.
max(X,Y,X):- X>Y.
