delete([],N,[]).       //N is position of the element to be deleted
delete([List],1,[]).
delete([Head|List1],1,List1).
delete([Head|List],N,[Head|List1]):-
	N1 is N-1,
	N1>0,
	delete(List,N1,List1).
