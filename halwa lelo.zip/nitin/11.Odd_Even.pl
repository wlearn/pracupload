even([]).
even([H|T]):-
odd(T).
odd([H|T]):-
even(T).