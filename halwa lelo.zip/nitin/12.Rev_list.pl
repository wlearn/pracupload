conc([],L,L).
conc([X|L1],L2,[X|L3]):-conc(L1,L2,L3).
rev([H],[H]).
rev([H|T],X):-
	rev(T,X1),
	conc(X1,[H],X).
