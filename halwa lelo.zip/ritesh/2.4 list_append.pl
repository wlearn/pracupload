append([],L,L).
append([X|T],L2,[X|T1]) :- append(T,L2,T1).
