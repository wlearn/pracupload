maxlist([A],A).
maxlist([X|T],R) :- 	maxlist(T,R1),
	     	(X>=R1,	R = X ; X<R1, R = R1).