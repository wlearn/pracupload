class(person).
class(male).
class(female).

hasa(john,[27,70,181]).
hasa(jane,[24,50,170]).
hasa(mary,[1,6,60]).


isa(male,person).
isa(female,person).
isa(john,male).
isa(jane,female).

isaperson(X):- isa(X,person),!.
isaperson(X):- isa(X,Y), isa(Y,person),!.


propof(X,L):-isaperson(X), hasa(X,L).
