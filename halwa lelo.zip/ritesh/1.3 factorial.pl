fact(0,R) :- R is 1.
fact(X,R) :- X>0,
                    X1 is X-1,
                    fact(X1,R1),
                    R is X*R1.