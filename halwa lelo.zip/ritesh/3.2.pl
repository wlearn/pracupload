%Prolog program to find maximum of two maximum of 2 numbers.

maxm(X, Y, Max):- X >= Y,
				  Max is X ; Max is Y.
