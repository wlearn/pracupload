%Prolog program to find the sum of the elements in the list.


sumList([H|Tail], Sum):- sum(Tail, H, Sum).

sum([], Sum, Sum).

sum([H|Tail], Temp, Sum):- 
						   S1 is Temp + H,
					       sum(Tail, S1, Sum).
