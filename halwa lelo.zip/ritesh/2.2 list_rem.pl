remove_nth(1,[X|T],T).
remove_nth(N,[X|T],[X|T1]) :- 	N1 is N-1,
			remove_nth(N1,T,T1).