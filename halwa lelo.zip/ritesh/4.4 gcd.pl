gcd(0,B,B).
gcd(A,B,R) :- A1 is mod(B,A),
                       gcd(A1,A,R).