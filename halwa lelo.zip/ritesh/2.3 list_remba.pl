remove-nth(1,[X|T],[],T).
remove-nth(N,[X|T],[X|T1],T2) :- N1 is N-1,
			   remove-nth(N1,T,T1,T2).