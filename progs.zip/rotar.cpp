#include<iostream>
#include<stdlib.h>
#include<string.h>
using namespace std;
int main()
{
	int temp,j,i,k,key1[26],key[26]={'l','q','u','x','z','g','m','r','u','y','d','h','n','s','w','b','e','i','j','o','t','a','c','f','k','p'};
	char pt1[100],pt[100], ct[100];
	cout<<"\n Enter plane text ";
	cin>>pt;
	for(i=0; i<26; i++)
		key1[i]=key[i];
	int ptlen;
	ptlen=strlen(pt);
	for(j=0; j<ptlen; j++)
	{
		ct[j]=key1[pt[j]-'a'];
		temp=key1[0];
		for(k=0; k<25; k++)
		{
			key1[k]=key1[k+1];
		}
		key1[25]=temp;
	}
	cout<<endl<<ct;
	for(j=0; j<ptlen; j++)
	{
		for(k=0; k<26; k++)
		{
			if(ct[j]==key[k])
				break;
		}
		pt1[j]=k+'a';
		temp=key[0];
		for(k=0; k<25; k++)
		{
			key[k]=key[k+1];
		}
		key[25]=temp;
	}
	cout<<endl<<pt1;
}
