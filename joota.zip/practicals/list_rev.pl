append([],L,L).
append([X|T],L2,[X|T1]) :- append(T,L2,T1).
reverse([],[]).
reverse([X|T],L) :- 	reverse(T,L1),
		append(L1,[X],L).
	             
