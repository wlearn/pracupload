len([],0).
len([X|T],R) :- len(T,R1),
	       R is R1+1.

evenlength(L) :- len(L,R1),
	          R is mod(R1,2),
	          R==0.

oddlength(L) :- len(L,R1),
	        R is mod(R1,2),
	        R\=0.