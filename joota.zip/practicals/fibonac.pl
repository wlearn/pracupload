fib(1,0).
fib(2,1).
fib(N,R) :- N>1,
	X is N-1,
	Y is N-2,
                 fib(X,R1),
	fib(Y,R2),
	R is R1+R2.