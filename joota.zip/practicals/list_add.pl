add([],0).
add([X|T],R) :- add(T,R1),
	        R is X+R1.