len([],0).
len([X|T],R) :- len(T,R1),
	       R is R1+1.