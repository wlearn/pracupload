parent(pam,bob).
parent(tom,bob).
parent(bob,ann).
parent(bob,pat).
parent(pat,jim).
female(pam).
female(ann).
male(bob).
male(pat).
male(tom).
male(jim).
mother(X,Y) :- parent(X,Y),female(X).
father(X,Y) :- parent(X,Y),male(X).
child(X,Y) :- parent(Y,X).
predecessor(X,Y):-parent(X,Y).
predecessor(X,Y):-parent(X,Z),predecessor(Z,Y).
spouse(X,Y) :- child(Z,X),child(Z,Y).
sibling(X,Y) :- parent(Z,X),parent(Z,Y).