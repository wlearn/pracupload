member(X,[X|T]).
member(X,[Y|T]) :- member(X,T).