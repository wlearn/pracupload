%even odd
disp([]):- 
