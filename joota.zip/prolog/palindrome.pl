concat([],[],[]).
concat([H],T,)
reverse()
