%append
appendlist([],X,[X]).
appendlist([H|T],X,[H|T1]):-
	appendlist(T,X,T1).
