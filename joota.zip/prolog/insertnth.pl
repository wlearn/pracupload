%insert_nth(item,list,result)
