nth(1,[X|_],X).
nth(N,[_|T],X):-
	N1 is N-1,
	nth(N1,T,X).
