% all permutations of a list
remove(X,[X|T],T).  
remove(X,[H|T],[H|T1]):-
	remove(X,T,T1).
perm([],[]).
perm([X|T],L):-
	perm(T,L1), remove(X,L,L1).
