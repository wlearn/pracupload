%Write a prolog program to find the maximum of two numbers.

max(X,X,X):- !.
max(X,Y,X):- X>=Y,!.
max(_,Y,Y).
