%Write a prolog program to calculate the sum of two numbers

sum(N1,N2,S):- S is N1+N2.
