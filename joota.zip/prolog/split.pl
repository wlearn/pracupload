split([],[],[]).
split([H|T],[H|T1],T2):-
	H>=0,
	split(T,T1,T2).
split([H|T],T1,[H|T2]):-
	H<0,
	split(T,T1,T2).
