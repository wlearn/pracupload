%remove nth item from list

remove-nth(1,[_|T],T).
remove-nth(N,[H|T],[H|T1]):-
	N1 is N-1,
	remove-nth(N1,T,T1).
