%Write a prolog program to calculate the nth Fibonacci number.

fibonacci
