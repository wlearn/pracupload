package in.example.pracfour;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText call,message,search,view;
    Button bt_call,bt_message,bt_search,bt_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // call
        call = (EditText) findViewById(R.id.call);
        bt_call = (Button) findViewById(R.id.btn_call);
        bt_call.setOnClickListener(MainActivity.this);
        // message
        message = (EditText) findViewById(R.id.msg);
        bt_message = (Button) findViewById(R.id.btn_msg);
        bt_message.setOnClickListener(MainActivity.this);
        // search
        search = (EditText) findViewById(R.id.search);
        bt_search = (Button) findViewById(R.id.btn_search);
        bt_search.setOnClickListener(MainActivity.this);
        // view
        view = (EditText) findViewById(R.id.view);
        bt_view = (Button) findViewById(R.id.btn_view);
        bt_view.setOnClickListener(MainActivity.this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        String str;
        Intent in = new Intent();
        switch (id) {
            case R.id.btn_call:
                str = call.getText().toString();
                if (!str.isEmpty()) {
                    in.setAction(Intent.ACTION_DIAL);
                    in.setData(Uri.parse("tel: " +str));
                    startActivity(in);
                }
                break;

            case R.id.btn_msg:
                str = message.getText().toString();
                if (!str.isEmpty()) {
                    in.setAction(Intent.ACTION_SEND);
                    in.setType("text/plain");
                    in.putExtra(Intent.EXTRA_TEXT,str);
                    startActivity(in);
                }
                break;

            case R.id.btn_search:
                str = search.getText().toString();
                if(!str.isEmpty()) {
                    in.setAction(Intent.ACTION_WEB_SEARCH);
                    in.putExtra(SearchManager.QUERY,str);
                    startActivity(in);
                }
                break;

            case R.id.btn_view:
                str = view.getText().toString();
                if(!str.isEmpty()) {
                    in.setAction(Intent.ACTION_VIEW);
                    in.setData(Uri.parse("http://" + str));
                    startActivity(in);
                }
                break;
        }
    }
}
