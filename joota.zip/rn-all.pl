rn-all(1,_,[]).
rn-all(N,[H|T],[H|T1]):- 
	N1 is N-1,
	rn-all(N1,T,T1),
	write("List is "+T1+"\n").
