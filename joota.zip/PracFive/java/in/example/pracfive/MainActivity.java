package in.example.pracfive;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    Spinner jaddu;
    ImageView androids;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        androids = (ImageView) findViewById(R.id.imageView);
        jaddu = (Spinner) findViewById(R.id.spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        jaddu.setAdapter(adapter);
        jaddu.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        androids.setImageResource(R.drawable.jellybean);
                        break;

                    case 1:
                        androids.setImageResource(R.drawable.kitkat);
                        break;

                    case 2:
                        androids.setImageResource(R.drawable.lollipop);
                        break;

                    case 3:
                        androids.setImageResource(R.drawable.marshmallow);
                        break;

                    case 4:
                        androids.setImageResource(R.drawable.nougat);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

}