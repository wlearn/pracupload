package in.example.practicaltwelve;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import static android.R.attr.version;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "marksManager";

    // Contacts table name
    private static final String TABLE_MARKS = "markssheet";

    // Contacts Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_MARKS = "marks";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, version);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_MARKS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT,"
                + KEY_MARKS + " TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MARKS);

        // Create tables again
        onCreate(db);
    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */

    // Adding new contact
    void addMarks(model mode) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, mode.get_name()); // Contact Name
        values.put(KEY_MARKS, mode.get_marks()); // Contact Phone

        // Inserting Row
        db.insert(TABLE_MARKS, null, values);
        db.close(); // Closing database connection
    }

    // Getting single contact
    model getContact(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_MARKS, new String[] { KEY_ID,
                        KEY_NAME, KEY_MARKS }, KEY_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        model mode = new model(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), cursor.getString(2));
        // return contact
        return mode;
    }

    // Getting All Contacts
    public List<model> getAllMarks() {
        List<model> contactList = new ArrayList<model>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_MARKS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                model mode = new model();
                mode.set_id(Integer.parseInt(cursor.getString(0)));
                mode.set_name(cursor.getString(1));
                mode.set_marks(cursor.getString(2));
                // Adding contact to list
                contactList.add(mode);
            } while (cursor.moveToNext());
        }

        // return contact list
        return contactList;
    }

    // Updating single contact
    public int updateMarks(model mode) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, mode.get_name());
        values.put(KEY_MARKS, mode.get_marks());

        // updating row
        return db.update(TABLE_MARKS, values, KEY_ID + " = ?",
                new String[] { String.valueOf(mode.get_id()) });
    }

    // Deleting single contact
    public void deleteContact(int mode) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_MARKS, KEY_ID + " = ?",
                new String[] { String.valueOf(mode) });
        db.close();
    }


    // Getting contacts Count
    public int getContactsCount() {
        String countQuery = "SELECT  * FROM " + TABLE_MARKS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }
}
