package in.example.practicaltwelve;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Update extends AppCompatActivity implements View.OnClickListener{
    EditText editText;
    EditText editText1;
    EditText editText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        editText = (EditText)findViewById(R.id.id);
        editText1=(EditText)findViewById(R.id.name);
        editText2=(EditText)findViewById(R.id.marks);
    }


    @Override
    public void onClick(View view) {
        String name,marks,roll;
        int id;
        roll=editText.getText().toString();
        id=Integer.parseInt(roll);
        name=editText1.getText().toString();
        marks=editText2.getText().toString();
        if(name.matches("")||marks.matches("")||roll.matches(""))
        {
            Toast.makeText(this,"Incomplete or Mismatch data",Toast.LENGTH_SHORT).show();
        }
        else {
            DatabaseHandler db = new DatabaseHandler(this);
            int result = db.updateMarks(new model(id,name,marks));
            if(result==0)
            {
                    Toast.makeText(this,"0 Rows affected",Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this,result+" rows affected",Toast.LENGTH_SHORT).show();
            }
        }

    }
}
