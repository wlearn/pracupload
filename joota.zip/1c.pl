%Write a prolog program to calculate the factorial of a given number.

factorial(0,R):- R is 1.
factorial(N,R):- N>0, N1 is N-1, factorial(N1,R1), R is R1*N.
