% flatten(list,flatlist):- list=list(list) and flatlist=simple elements of given list are recognized as one plain list
conc([],[],[]).
conc([],L2,L2).
conc(L1,[],L1).
conc([H|T1],T2,[H|T3]):-
	conc(T1,T2,T3).
	
flatten([H|T],L):-
	flatten(H,H1),
	flatten(T,T1),
	conc(H1,T1,L),
	!.
flatten([],[]).
flatten(X,[X]).
