package in.example.practwelve;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner jaddu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        jaddu = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        jaddu.setAdapter(adapter);
        jaddu.setOnItemSelectedListener(MainActivity.this);

        Context context = MainActivity.this;
        SQLiteDatabase db = context.openOrCreateDatabase("records.db", Context.MODE_PRIVATE, null);
//        db.execSQL("DROP TABLE STUDENT");

        db.execSQL("CREATE TABLE IF NOT EXISTS STUDENT ( ID INTEGER NOT NULL PRIMARY KEY, " +
            "NAME TEXT NOT NULL, MARKS INTEGER)");


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}