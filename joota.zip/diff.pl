ismember(X,[X|_]).
ismember(X,[_|T]):- 
	ismember(X,T).

diff([],_,[]).
diff([H|T],L2,L3):- 
	ismember(H,L2),
	!,
	diff(T,L2,L3).
diff([H|T],L2,[H|L3]):-
	diff(T,L2,L3).
