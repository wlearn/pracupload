%member with pos
pos(X,[X|_],1):- write("Found\n").
pos(X,[_|T],P):- 
	pos(X,T,P1),
	P is P1+1.
