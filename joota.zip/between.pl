%generate numbers between 2 given numbers including both
between(X,X):- write(X),!.
between(X,Y):-
	write(X), 
	write("\n"),
	X1 is X+1,
	between(X1,Y).
