#include<iostream>
#include<string.h>
#include<stdio.h>
#include<cmath>
using namespace std;
void decrypt(char arr[][100],int row,int col,int len)
{
	int i,j,k=0,col_num=0,row_num=0;
	char decrypt_text[50];
	for(i=0;i<row;i++)
		for(j=0;j<col;j++)
		{
			decrypt_text[k]=arr[i][j];
			k++;
		}	
	decrypt_text[k]='\0';
	col_num=0,row_num=0;
	for(i=0;i<k;i++)
	{
		arr[row_num][col_num]=decrypt_text[i];
		row_num++;
		if(row_num==row)
		{
			row_num=0;
			col_num++;
		}
	}
	k=0;
	for(i=0;i<row;i++)
		for(j=0;j<col;j++)
		{
			decrypt_text[k]=arr[i][j];
			k++;
		}		
	decrypt_text[len]='\0';
	cout<<"\nDecrpyted text is "<<decrypt_text<<"\n";
}
void encrypt(char arr[][100],int row,int col,int len)
{
	int i,j,k=0;
	char encrypt_text[50];
	for(i=0;i<col;i++)	
		for(j=0;j<row;j++)
		{
			encrypt_text[k]=arr[j][i];
			k++;
		}
	encrypt_text[k]='\0';
	cout<<"\nEncrpyted text is "<<encrypt_text<<"\n";
	decrypt(arr,row,col,len);
}
void generate_arr(char text[100],char arr[][100],int row,int col,int len)
{
	int i,j,k=0;
	for(i=0;i<row;i++)		
		for(j=0;j<col;j++)		
		{
			while(text[k]==' ')						
			{
				if(k<len)
					k++;		
				else 
					break;
			}
			arr[i][j]=text[k];			
			if(k<len)				
				k++;
			else 
				break;
		}
	//adding bogus character where array is not filled
	if((row*col)>len)
	{
		k=row*col-len;
		for(i=0;i<k;i++)
			arr[row-1][col-i-1]='x';
	}
	k=0;
	char encrypt_text1[50];
	for(i=0;i<col;i++)	
		for(j=0;j<row;j++)
		{
			encrypt_text1[k]=arr[j][i];
			k++;
		}
	encrypt_text1[k]='\0';
	k=0;
	//generating array from first encrypted text
	for(i=0;i<row;i++)		
		for(j=0;j<col;j++)		
		{
			arr[i][j]=encrypt_text1[k];			
			k++;
		}
}
int removespace(char text[100])
{
	int len=strlen(text),i,j;
	for(i=0;i<len;i++)
	{
		if(text[i]==' ')
		{
			for(j=i;j<len-1;j++)
			{
				text[j]=text[j+1];				
			}
			len--;
		}
	text[len]='\0';
	}
	return len;
}
int main()
{
	char text[100],arr[100][100];
	int i=0,j,col,len=0,row;
	cout<<"\nEnter the text(in lower case)\n";
	cin.getline(text,100);
	len=removespace(text);
	cout<<"\nEnter the number of columns into which the text is to be divided\n";
	cin>>col;
	row=ceil((float)len/(float)col);
	generate_arr(text,arr,row,col,len);
	encrypt(arr,row,col,len);
	return 0;	
}
