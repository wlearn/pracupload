#include<iostream>
using namespace std;
int main()
{
	char key[30]="kpznlwabxrtsmcogideuqyfhvj",text[100],ctext[100],dctext[100],ch,c,ch1;
	int i,j=0,pos=0;
	cout<<"\nEnter the plain text\n";
	cin>>text;
	while(1)
	{
		ch=text[j];
		if(ch=='\0')
			break;
		else
		{
			
			c=ch-97;
			ch1=key[c];
			ctext[j]=ch1;			
			for(pos=0;pos<26;pos++)
			{
				if(ch1==key[pos])
					break;
			}
			c=pos+97;
			dctext[j]=c;
		}
		j++;
	}
	ctext[j]='\0';
	dctext[j]='\0';
	cout<<"\nEncrypted text is- "<<ctext;
	cout<<"\nDecrypted text is- "<<dctext<<"\n";	
	return 0;
}
