#include<iostream>
#include<string.h>
using namespace std;
void generate_array(char arr[26][26])
{
	int i=0,j=0;	
	for(i=0;i<26;i++)
		for(j=0;j<26;j++)		
			arr[i][j]=(char)((i+j)%26+65);				
}
void decrypt(char encrypt_text[],int len_encrypt_text,char key[],int len_key,char arr[26][26])
{
	int row,col,i,j,k;
	char decrypt_text[20],ch,ch1;
	for(k=0;k<len_encrypt_text;k++)
	{
		ch=encrypt_text[k];
		ch1=key[(k%len_key)];
		row=(int)ch1-97;
		for(col=0;col<26;col++)
		{
			if(ch==arr[row][col])
				break;
		}
		decrypt_text[k]=(char)(97+col);
	}
	decrypt_text[k]='\0';
	cout<<"\nDecrpyted text is "<<decrypt_text<<"\n";
}
void encrypt(char text[],int len_text,char key[],int len_key,char arr[26][26])
{
	int row,col,i,j,k;
	char encrypt_text[20],ch,ch1;
	for(k=0;k<len_text;k++)
	{
		ch=text[k];
		ch1=key[(k%len_key)];
		col=(int)ch-97;
		row=(int)ch1-97;
		encrypt_text[k]=arr[row][col];
	}
	encrypt_text[k]='\0';
	cout<<"\nEncrpyted text is "<<encrypt_text<<"\n";
	decrypt(encrypt_text,len_text,key,len_key,arr);
}
int main()
{
	char key[20],arr[26][26],a,text[20];
	int i,j,flag,length,done,len;
	cout<<"\nEnter the length of key to be inserted\n";	
	cin>>length;
	cout<<"\nEnter the key(in lower case)\n";
	cin>>key;
	key[length]='\0';
	generate_array(arr);
	cout<<"\nEnter the length of the text to be entered\n";
	cin>>len;
	cout<<"\nEnter the text(in lower case)\n";
	cin>>text;
	text[len]='\0';	
	encrypt(text,len,key,length,arr);
	return 0;	
}
