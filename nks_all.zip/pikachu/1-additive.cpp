#include<iostream>
#include<string.h>
#include<stdlib.h>
using namespace std;
void decrypt(char encrypt_text[],int len_encrypt_text,int key)
{
	int pt,ky,ct,k;
	char decrypt_text[20];
	for(k=0;k<len_encrypt_text;k++)
	{
		ct=(int)(encrypt_text[k])-64;
		if(ct>=key)
			pt=(ct-key)+96;
		else
			pt=(ct-key+26)+96;
		decrypt_text[k]=(char)pt;
	}
	decrypt_text[k]='\0';
	cout<<"\nDecrpyted text is "<<decrypt_text<<"\n";
}
void encrypt(char text[],int len,int key)
{
	char encrypt_text[20];
	int pt,ky,ct,k;
	for(k=0;k<len;k++)
	{
		pt=(int)(text[k])-96;	
		ct=(pt+key)%26+64;
		encrypt_text[k]=(char)ct;
	}
	encrypt_text[k]='\0';
	cout<<"\nEncrpyted text is "<<encrypt_text;
	decrypt(encrypt_text,len,key);
}
int main()
{
	char text[20];
	int i,rand_val,len,key;
	cout<<"\nEnter the length of the text to be entered\n";
	cin>>len;
	cout<<"\nEnter the text(in lower case)\n";
	cin>>text;
	text[len]='\0';	
	cout<<"\nEnter the key\n";
	cin>>key;
	encrypt(text,len,key);
	return 0;	
}
