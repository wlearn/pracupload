#include<iostream>
#include<string.h>
using namespace std;
int turn_pos(int det)
{
	if(det>0)
		return det;
	//cout<<"hey";
	turn_pos(det+26);
	
}
int main()
{
	char key[4]; //key in charter
	int key1[2][2],i,j, key_inv[2][2]; //key1 for key in integer matrix 2*2
	cout<<"\n Enter 4 character key ";
	cin>>key;
	int k=0;
	for(i=0; i<2; i++)// CONVERTING KEY TO MATRIX
	{
		for(j=0; j<2; j++)
		{
			key1[i][j]=toupper(key[k])-65;
			//cout<<key1[i][j];
			k++;
		}
	}
	char pt[50];	//pt in characters
	cout<<"\n Enter plane text ";
	cin>>pt;
	int ptlen=strlen(pt);
	//cout<<ptlen<<endl;
	int n=ptlen;
	if(n%2!=0)
		++n; 
	//cout<<n;
	n=n/2;
	int a[2][n], ct[2][n], ot[2][n];
	k=0;
	char temp;
	for(i=0; i<n; i++)	//plain text into matrix 2*n (n = total letters/2)
	{
		for(j=0; j<2; j++)
		{
			if(k<ptlen)			
				a[j][i]=toupper(pt[k]);
			else
				a[j][i]='X';
			//cout<<a[j][i]<<endl;
			k++;
		}
	}
	
	
	int sum,c, d ;		
	for(i=0;i<2;i++){ //row of first matrix
      		for(j=0;j<n;j++){  //column of second matrix
           		sum=0;
           		for(k=0;k<2;k++)
               			sum=sum+(key1[i][k])*(a[k][j]-65);
			//cout<<sum;
           		ct[i][j]=(sum%26)+65;
			//cout<<ct[i][j];			
			temp=ct[i][j];
			cout<<temp<<endl;
      		}
      }
	
	int det,tep, inv;
	det=(key1[0][0]*key1[1][1])-(key1[0][1]*key1[1][0]);
	if(det<0)
		tep=turn_pos(det);
	else if(det==0)
		cout<<"key matrix invalid";
	else
		tep=det;
	det=tep;
 	cout<<" determinant is "<<det;
	for(int j=0; j<26; j++)
			{
				if(((det*j)%26)==1)
				{
					inv=j;
					break;
				}
			}
			cout<<"\n inv of det is"<<inv;
	key_inv[0][0]=(key1[1][1]*inv)%26;
	key_inv[0][1]=(turn_pos(-key1[0][1])*inv)%26;
	key_inv[1][0]=(turn_pos(-key1[1][0])*inv)%26;
	key_inv[1][1]=(key1[0][0]*inv)%26;
	//cout<<endl<<ct[0][0]-65<<endl<<ct[1][0]-65<<endl;
	//cout<<endl<<key_inv[0][0]<<endl<<key_inv[0][1]<<endl<<key_inv[1][0]<<endl<<key_inv[1][1];
	for(i=0;i<2;i++){ //row of first matrix
      		for(j=0;j<n;j++){  //column of second matrix
           		sum=0;
           		for(k=0;k<2;k++)
				sum=sum+(key_inv[i][k])*(ct[k][j]-65);			
			//cout<<sum;
           		ot[i][j]=(sum%26)+65;
			//cout<<ct[i][j];			
			temp=ot[i][j];
			//cout<<temp<<endl;
      		}
      }
	cout<<"\n The text is ";
	for( i=0; i<n; i++)
	{
		for(j=0; j<2; j++)
		{
			temp=ot[j][i];
			cout<<temp;
		}
	}
}
