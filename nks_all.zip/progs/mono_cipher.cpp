#include<iostream>
#include<stdlib.h>
#include<string.h>
//#include<vector>
using namespace std;
void shuffle(char * a, int n)
{
      int i = n - 1;
      int j, temp;

     // random(time(NULL));
	//randomize();
      while (i > 0)
      {
            j = random() % (i + 1);
            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
            i = i - 1;
      }
}
int main()
{
	char key[26];
	char pt[20], ct[20],pt1[26];	
	int n,j,i;
	for(i=0; i<25; i++)
	{
		key[i]=i+65;
	}
	shuffle(key,26);
	cout<<"\n Enter plain text ";
	cin>>pt;
	//cout<<pt;
	n=strlen(pt);
	for( j=0; j<n; j++)
	{
		if(pt[j]>='A' && pt[j]<='Z')
		{
			pt[j]=pt[j]-65;
			ct[j]=key[pt[j]];
		}
		else if(pt[j]>='a' && pt[j]<='z')
		{
			pt[j]=pt[j]-97;
			ct[j]=key[pt[j]];
		}
	}
	ct[n]='\0';
	cout<<endl<<"The cipher text is "<<ct;
	for(j=0; j<n; j++)
	{
		for(i=0; i<26; i++)
		{
			if(key[i]==ct[j])
			break;
		}
		pt1[j]=i+65;
	}
	pt1[n]='\0';
	cout<<endl<<"The plane text is "<<pt1;		
}
