#include<iostream>
using namespace std;
#include<string.h>
#include<math.h>
int main()
{
	
	float keylen,ptlen;	
	char key[10],pt[100];
	cout<<"enter plain text ";
	cin>>pt;
	cout<<"\n enter key";
	cin>>key;
	ptlen=strlen(pt);
	keylen=strlen(key);
	int r=ceil(ptlen/keylen);
	//cout<<c;
	int klen=keylen;
	int i,j,k=0,pt_m[r][klen];
	for(i=0; i<r; i++)
	{
		for(j=0; j<klen; j++)
		{
			if(k>=ptlen)
				pt_m[i][j]='-';
			else
			{
				pt_m[i][j]=pt[k];
				k++;
			}	
		}	
	}
	
	int a[26];
	for(i=0; i<26; i++)
		a[i]=-1;
	for(i=0; i<klen; i++)
	{
		a[key[i]-'a']=i;
	}
	//for(i=0; i<26; i++)
	//	cout<<a[i];
	cout<<endl;
	int ct[r][klen];
	k=0;	
	for(i=0; i<26; i++)
	{
		
		if(a[i]!=-1)
		{
			//cout<<"hi";
			for(j=0; j<r; j++)
			{
				//cout<<(char)pt_m[j][a[i]];
				ct[j][k]=pt_m[j][a[i]];	
				//cout<<j<<k<<endl;		
			}k++;
		}
		
	}
	char cit[100];
	k=0;
	for(i=0; i<klen; i++)
	{
		for(j=0; j<r; j++)
		{
			//cout<<k;			
			cit[k]=(char)ct[j][i];
			k++;
		}
	
	}
	cit[k]='\0';
	cout<<"\n the cipher text is "<<cit;
}
