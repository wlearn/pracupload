#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<time.h>
using namespace std;

int main()
{
	int k,ptlen,ptlen2,key[5][5]={'l','g','d','b','a','q','m','h','e','c','u','r','n','i','f','x','v','s','o','k','z','y','w','t','p'},i,j;
	char pt[100],pt_new[100], ct[100];	
	cout<<"\n Enter plain text ";
	cin>>pt;
	ptlen=strlen(pt);
	k=0;
	for(i=0; i<ptlen-1; i++)
	{
		pt[i]=tolower(pt[i]);
		j=i+1;
		pt_new[k]=pt[i];
		if(pt_new[k]=='j')
			pt_new[k]='i';
		
		if(pt[i]==pt[j])
		{
			k++;
			pt_new[k]='x';
		}
	k++;
	}
	pt_new[k]=tolower(pt[i]);
	if(pt[i]=='j')
		pt_new[k]='i';
	pt_new[k+1]='\0';
	//cout<<endl<<pt_new;
	ptlen2=strlen(pt_new);
	if(ptlen2%2!=0)
	{
		pt_new[ptlen2]='x';
		ptlen2+=1;
	}	
	pt_new[ptlen2]='\0';
	cout<<endl<<pt_new;
	int m,n,o,p;
	for(i=0 ; i<ptlen2; i=i+2)
	{
		for(j=0; j<5; j++)
		{
			for(k=0; k<5; k++)
			{
				if(key[j][k]==pt_new[i])
				{
					m=j;
					n=k;
				}
			}	
		}
		for(j=0; j<5; j++)
		{
			for(k=0; k<5; k++)
			{
				if(key[j][k]==pt_new[i+1])
				{
					o=j;
					p=k;
				}
			}	
		}
		if(m==o)
		{
			ct[i]=key[m][(n+1)%5];
			ct[i+1]=key[o][(p+1)%5];
		}
		else if(n==p)
		{
			ct[i]=key[(m+1)%5][n];
			ct[i+1]=key[(o+1)%5][p];
		}
		else
		{
			ct[i]=key[m][p];
			ct[i+1]=key[o][n];
		}	
	}
	ct[ptlen2]='\0';
	cout<<"\n "<<ct;
}
