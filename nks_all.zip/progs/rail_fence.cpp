#include<iostream>
#include<string.h>
using namespace std;
int main()
{
	char wd[100], ctext[100], ptext[100];
	
	int len;
	cout<<" \n Enter the word to encrpt ";
	cin>>wd;
	len=strlen(wd);
	//cout<<len;
	if(len%2!=0)
	{
		wd[len]='x';
		wd[len+1]='\0';
		len=len+1;
	}
	int ct[2][len/2], i, j, k=0;
	for(i=0; i<len/2; i++)
	{
		for(j=0; j<2; j++)
		{
			ct[j][i]=wd[k];
			k++;
		}
		//if(k==len)
		//	break;
	}
	k=0;
	for(i=0; i<2; i++)
	{
		for(j=0; j<len/2; j++)
		{
			ctext[k]=ct[i][j];
			k++;		
		}
		
		
	}
	ctext[k]='\0';
	cout<<"\n The cipher text is"<<ctext;
	int pt[2][len/2];
	k=0;
	for(i=0; i<2; i++)
	{
		for(j=0; j<len/2; j++)
		{
			pt[i][j]=ctext[k];
			k++;		
		}
	}
	k=0;
	for(i=0; i<len/2; i++)
	{
		for(j=0; j<2; j++)
		{
			ptext[k]=pt[j][i];
			k++;
		}
		//if(k==len)
		//	break;
	}
	ptext[k]='\0';
	cout<<"\n The plain text is "<<ptext;
	
}

