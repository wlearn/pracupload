#include<iostream>
#include<string.h>
#include<time.h>
#include<stdlib.h>
using namespace std;
int main()
{
	char key[50], pt[50], ct[50], pt1[50];
	int keylen, ptlen,i,j, temp;
	//cout<<"\n Enter the key ";
	//cin>>key;
	cout<<" \n Enter Plane text ";
	cin>>pt;
//	keylen=strlen(key);
	ptlen=strlen(pt);
	for(i=0; i<ptlen; i++)
	{
		srand((unsigned)time(0));
		key[i]=(rand()%26)+65;
	}
	for(i=0; i<ptlen; i++)
		pt[i]=toupper(pt[i]);
	for(i=0; i<ptlen; i++)
	{
		//temp=i%keylen;
		ct[i]=(((pt[i]-65)+(key[i]-65))%26)+65;
		//cout<<ct[i]<<" ";
		//ct[i]=ct[i]+65;
	}
	ct[ptlen]='\0';		
	cout<<"\n THE CIPHER TEXT IS "<<ct<<endl;
	int ctlen=strlen(ct);
	for(i=0; i<ctlen; i++)
	{
		//temp=i%keylen;
		pt1[i]=(((ct[i]-65)-(key[i]-65+26))%26);
		//cout<<ct[i]<<" ";
		if(pt1[i]<0)
		{
			pt1[i]=pt1[i]+26;
		}
		pt1[i]=pt1[i]+65;
	}
	pt1[ctlen]='\0';
	cout<<"\n THE plane TEXT IS "<<pt1<<endl;
}
