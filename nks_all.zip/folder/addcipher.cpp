#include <iostream>
#include <stdlib.h>
#include <string.h>
using namespace std;

class AddCipher {
private:
	char *str;
	int key1,key2,len;
public:
	char* encrypt();
	char* decryp(char *);
	void get();
	AddCipher(char *s,int k1) {
		str=s;
		key1=k1;
		key2=26-k1;
		len=strlen(s);
	}
	
};

char *AddCipher::encrypt () {
	char *estr;
    for(int i=0; i<strlen(s); i++)
        estr[i]=(((this.str[i]-97)+key1)%26)+97;
	estr[i]='\0';        
    return estr;
}

char *AddCipher::decrypt (char *c) {
    char *dstr;
    for(int i=0; i<len; i++) 
        dstr[i]=(((c[i]-97)+key2)%26)+97;
    return c;
}



int main () {
    system("clear");
	char *str,*code,*out;
	int key;
    cout<< "Enter the string: ";
    cin>>str;
    cout<< "Enter the key: ";
    cin>>key;
    AddCipher a(str,key);
	code=a.encrypt(this.str);
	out=a.decrypt(code);
    return 0;
}
