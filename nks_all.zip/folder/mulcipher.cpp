#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
using namespace std;

int mulInvKey(int k) {
	int r1=26,r2=k;
	int t1=0,t2=1,t=0;
	int r=0,q=0;
	while(r2>0) {
		q=r1/r2;
		r=r1-q*r2; r1=r2; r2=r;
		t=t1-q*t2; t1=t2; t2=t;
	}
	if(t1<0)
		t1+=26;
	return t1;
}

class MulCipher {
	public:
	int key;
	char str[30],estr[30],dstr[30];
	MulCipher() {
		strcpy(dstr," ");
		strcpy(estr," ");
	}
	void encrypt(char s[]) {
		int i=0,len=strlen(s);
		for(i=0; i<len; i++)
			estr[i]=(((s[i]-97)*key)%26)+97;
		estr[i]='\0';
		return;
	}
	void decrypt(char s[]) {
		int i=0,len=strlen(s);
		int key2=mulInvKey(key);
		for(i=0; i<len; i++)
			dstr[i]=(((s[i]-97)*mulInvKey(key))%26)+97;
		dstr[i]='\0';
		return;
	}
};


int main () {
    system("clear");
    char k[26];
    MulCipher obj;
    cout<< "Enter the string: ";
    cin>>obj.str;
    cout<<"Enter the key: ";
	cin>>obj.key;
    obj.encrypt(obj.str);
    cout<<"Encrypted string: "<<obj.estr<<endl;
    obj.decrypt(obj.estr);
    cout<<"Decrypted string: "<<obj.dstr<<endl;
    return 0;
}
